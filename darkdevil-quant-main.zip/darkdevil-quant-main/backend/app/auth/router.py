from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..audit import audit
from ..db import get_db
from ..models import User
from ..security import create_access_token, hash_password, verify_password
from .deps import get_current_user, require_role

router = APIRouter(prefix="/api/auth", tags=["auth"])


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    email: str


@router.post("/register", response_model=TokenOut, status_code=201)
async def register(body: RegisterIn, db: AsyncSession = Depends(get_db)):
    n = (await db.execute(select(func.count(User.id)))).scalar_one()
    role = "admin" if n == 0 else "viewer"  # first registered user bootstraps the admin
    existing = (await db.execute(select(User).where(User.email == body.email.lower()))).scalar_one_or_none()
    if existing:
        raise HTTPException(status.HTTP_409_CONFLICT, "email already registered")
    user = User(email=body.email.lower(), hashed_password=hash_password(body.password), role=role)
    db.add(user)
    await audit(db, "auth.register", detail={"email": user.email, "role": role})
    await db.refresh(user)
    token = create_access_token(user.id, user.role)
    return TokenOut(access_token=token, role=user.role, email=user.email)


@router.post("/login", response_model=TokenOut)
async def login(body: LoginIn, db: AsyncSession = Depends(get_db)):
    user = (await db.execute(select(User).where(User.email == body.email.lower()))).scalar_one_or_none()
    if not user or not user.is_active or not verify_password(body.password, user.hashed_password):
        await audit(db, "auth.login_failed", detail={"email": body.email.lower()})
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid credentials")
    token = create_access_token(user.id, user.role)
    await audit(db, "auth.login", actor_id=user.id)
    return TokenOut(access_token=token, role=user.role, email=user.email)


@router.get("/me")
async def me(user: User = Depends(get_current_user)):
    return {"id": user.id, "email": user.email, "role": user.role,
            "created_at": user.created_at.isoformat()}


@router.get("/users")
async def list_users(limit: int = 50, user: User = Depends(require_role("admin")),
                     db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(select(User).order_by(User.id).limit(min(limit, 200)))).scalars().all()
    return [{"id": u.id, "email": u.email, "role": u.role,
             "is_active": u.is_active, "created_at": u.created_at.isoformat()} for u in rows]
