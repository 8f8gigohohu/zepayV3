from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .auth.router import router as auth_router
from .config import get_settings
from .db import Base, init_engine
from .routers import credentials, markets, system, trading


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_engine()
    # Create tables at startup (M1). Migrations move to Alembic in M2.
    from .db import engine
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    try:
        yield
    finally:
        from .db import engine
        if engine is not None:
            await engine.dispose()


def create_app() -> FastAPI:
    s = get_settings()
    app = FastAPI(title=s.app_name, version="0.1.0", lifespan=lifespan,
                  docs_url="/api/docs", openapi_url="/api/openapi.json")
    app.add_middleware(CORSMiddleware, allow_origins=s.cors_origin_list,
                       allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
    app.include_router(auth_router)
    app.include_router(system.router)
    app.include_router(markets.router)
    app.include_router(credentials.router)
    app.include_router(trading.router)

    @app.get("/api/version")
    async def version():
        return {"app": s.app_name, "version": "0.1.0", "milestone": 1}
    return app


app = create_app()
