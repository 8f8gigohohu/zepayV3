import os
import sys
import tempfile
from pathlib import Path

# Make `app` importable and force a clean per-run SQLite DB for tests.
BACKEND_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BACKEND_DIR))

_tmp = tempfile.mkdtemp(prefix="djq-test-")
os.environ["DJQ_DATABASE_URL"] = f"sqlite+aiosqlite:///{_tmp}/test.db"
os.environ["DJQ_SECRET_KEY"] = "test-secret-key-0123456789abcdef-safe"
os.environ["DJQ_ENVIRONMENT"] = "development"
os.environ["DJQ_BINANCE_REST_PUBLIC_URL"] = "https://test.example/binance-public"
os.environ["DJQ_ZEBPAY_REST_URL"] = "https://test.example/zebpay"

import pytest
from httpx import ASGITransport, AsyncClient

import app.db as dbmod
from app.main import create_app


@pytest.fixture
async def client():
    app = create_app()
    dbmod.init_engine()
    # create tables on the raw engine connection
    async with dbmod.engine.begin() as conn:
        await conn.run_sync(dbmod.Base.metadata.create_all)
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c
