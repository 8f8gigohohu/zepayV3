# Automated tests - credentials in this file are synthetic test fixtures and exist
# only inside the temporary test database. They are never live application data.
import pytest

pytestmark = pytest.mark.asyncio


async def test_first_user_becomes_admin(client):
    r = await client.post("/api/auth/register", json={
        "email": "admin@example.com", "password": "correct-horse-99"})
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["role"] == "admin"
    assert body["access_token"]


async def test_second_user_is_viewer_and_rbac_enforced(client):
    await client.post("/api/auth/register", json={
        "email": "one@example.com", "password": "correct-horse-99"})
    r = await client.post("/api/auth/register", json={
        "email": "two@example.com", "password": "correct-horse-99"})
    token = r.json()["access_token"]

    # viewer cannot list users
    r2 = await client.get("/api/auth/users",
                          headers={"Authorization": f"Bearer {token}"})
    assert r2.status_code == 403


async def test_login_success_and_failure(client):
    await client.post("/api/auth/register", json={
        "email": "login@example.com", "password": "correct-horse-99"})
    ok = await client.post("/api/auth/login", json={
        "email": "login@example.com", "password": "correct-horse-99"})
    assert ok.status_code == 200
    bad = await client.post("/api/auth/login", json={
        "email": "login@example.com", "password": "wrong-pass-1"})
    assert bad.status_code == 401


async def test_me_requires_token(client):
    await client.post("/api/auth/register", json={
        "email": "me@example.com", "password": "correct-horse-99"})
    assert (await client.get("/api/auth/me")).status_code == 401
